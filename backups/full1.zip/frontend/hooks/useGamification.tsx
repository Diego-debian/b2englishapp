"use client";

import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useAuth } from "./useAuth";

export interface Achievement {
  id: string;
  title: string;
  description: string;
  criteria: (state: GamificationState) => boolean;
  unlocked: boolean;
}

export interface GamificationState {
  xp: number;
  level: number;
  streak: number;
  mistakes: number;
  achievements: Achievement[];
}

interface GamificationContextValue extends GamificationState {
  addXP: (amount: number) => void;
  incrementStreak: () => void;
  resetStreak: () => void;
  addMistake: () => void;
  clearProgress: () => void;
}

const GamificationContext = createContext<GamificationContextValue | undefined>(undefined);

function xpNeededForLevel(level: number): number {
  return 100 + (level - 1) * 20;
}

const baseAchievements: Achievement[] = [
  {
    id: "first-correct",
    title: "Primer acierto",
    description: "Responde correctamente a un verbo por primera vez.",
    criteria: (state) => state.streak >= 1,
    unlocked: false,
  },
  {
    id: "streak-3",
    title: "Racha 3",
    description: "Alcanza una racha de 3 respuestas correctas.",
    criteria: (state) => state.streak >= 3,
    unlocked: false,
  },
  {
    id: "streak-10",
    title: "Racha 10",
    description: "Consigue una racha de 10 respuestas correctas.",
    criteria: (state) => state.streak >= 10,
    unlocked: false,
  },
  {
    id: "level-5",
    title: "Nivel 5 alcanzado",
    description: "Sube al nivel 5.",
    criteria: (state) => state.level >= 5,
    unlocked: false,
  },
  {
    id: "no-mistakes",
    title: "Sin errores",
    description: "Completa una sesión sin cometer errores.",
    criteria: (state) => state.mistakes === 0 && state.xp > 0,
    unlocked: false,
  },
];

function makeDefaultState(): GamificationState {
  return {
    xp: 0,
    level: 1,
    streak: 0,
    mistakes: 0,
    achievements: baseAchievements,
  };
}

function loadStateFromStorage(key: string): GamificationState {
  if (typeof window === "undefined") return makeDefaultState();

  try {
    const stored = localStorage.getItem(key);
    if (!stored) return makeDefaultState();

    const parsed = JSON.parse(stored) as Partial<GamificationState>;
    const achievements = baseAchievements.map((base) => {
      const unlocked = (parsed.achievements ?? []).find((a) => a.id === base.id)?.unlocked ?? false;
      return { ...base, unlocked };
    });

    return {
      xp: typeof parsed.xp === "number" ? parsed.xp : 0,
      level: typeof parsed.level === "number" ? parsed.level : 1,
      streak: typeof parsed.streak === "number" ? parsed.streak : 0,
      mistakes: typeof parsed.mistakes === "number" ? parsed.mistakes : 0,
      achievements,
    };
  } catch {
    return makeDefaultState();
  }
}

export const GamificationProvider = ({ children }: { children: React.ReactNode }) => {
  // ✅ FIX: traer token también (evita "Cannot find name 'token'")
  const { user, token } = useAuth();

  // ✅ Estado independiente por usuario: cada user.id tiene su propia llave
  const storageKey = useMemo(
    () => (user ? `gamificationState_${user.id}` : "gamificationState_guest"),
    [user?.id],
  );

  // Inicializa desde storage usando la llave actual
  const [state, setState] = useState<GamificationState>(() => loadStateFromStorage(storageKey));

  // ✅ FIX CLAVE: cuando cambia el usuario / storageKey, recargar el estado de ESE usuario
  useEffect(() => {
    setState(loadStateFromStorage(storageKey));
  }, [storageKey]);

  // Sincronizar XP/level con backend (si existe)
  useEffect(() => {
    async function syncStats() {
      if (typeof window === "undefined") return;
      if (!user || !token) return;

      try {
        const apiBase = (process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8001").trim();
        const res = await fetch(`${apiBase}/stats/overview`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) return;
        const data = await res.json();

        setState((prev) => ({
          ...prev,
          xp: typeof data.total_xp === "number" ? data.total_xp : prev.xp,
          level: typeof data.level === "number" ? data.level : prev.level,
        }));
      } catch {
        /* ignore */
      }
    }

    syncStats();
  }, [user?.id, token]);

  // Persistir progreso por usuario
  useEffect(() => {
    if (typeof window === "undefined") return;

    const minimal = {
      ...state,
      achievements: state.achievements.map(({ id, title, description, unlocked }) => ({
        id,
        title,
        description,
        unlocked,
      })),
    };

    localStorage.setItem(storageKey, JSON.stringify(minimal));
  }, [state, storageKey]);

  // Desbloqueo automático de logros
  useEffect(() => {
    setState((prev) => {
      const updated = prev.achievements.map((ach) => {
        if (!ach.unlocked && ach.criteria(prev)) return { ...ach, unlocked: true };
        return ach;
      });
      return { ...prev, achievements: updated };
    });
  }, [state.streak, state.level, state.mistakes, state.xp]);

  function addXP(amount: number) {
    setState((prev) => {
      let xp = prev.xp + amount;
      let level = prev.level;

      while (xp >= xpNeededForLevel(level)) {
        xp -= xpNeededForLevel(level);
        level += 1;
      }

      return { ...prev, xp, level };
    });
  }

  function incrementStreak() {
    setState((prev) => ({ ...prev, streak: prev.streak + 1 }));
  }

  function resetStreak() {
    setState((prev) => ({ ...prev, streak: 0 }));
  }

  function addMistake() {
    setState((prev) => ({ ...prev, mistakes: prev.mistakes + 1 }));
  }

  function clearProgress() {
    setState((prev) => ({ ...prev, xp: 0, level: 1, streak: 0, mistakes: 0 }));
  }

  const value: GamificationContextValue = useMemo(
    () => ({
      ...state,
      addXP,
      incrementStreak,
      resetStreak,
      addMistake,
      clearProgress,
    }),
    [state],
  );

  return <GamificationContext.Provider value={value}>{children}</GamificationContext.Provider>;
};

export function useGamification(): GamificationContextValue {
  const ctx = useContext(GamificationContext);
  if (!ctx) throw new Error("useGamification must be used within a GamificationProvider");
  return ctx;
}
