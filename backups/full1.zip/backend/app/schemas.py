"""
schemas.py
-------------

Pydantic schemas for request and response bodies used throughout the API.
The schemas defined here are deliberately minimal and do not expose
internal fields such as password hashes.  They are intended to
reflect the underlying relational models defined in ``models.py`` and
support the multi‑user, gamified architecture of the platform.

When adding new endpoints, define corresponding request/response
schemas here to ensure consistent validation and serialisation.
"""

from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, Field, ConfigDict


# ---------------------------------------------------------------------------
# User schemas
# ---------------------------------------------------------------------------

class UserCreate(BaseModel):
    """Payload for registering a new user."""

    username: str = Field(..., min_length=3, max_length=50, description="Unique username")
    password: str = Field(..., min_length=6, description="Plaintext password (will be hashed)")


class UserOut(BaseModel):
    """Public representation of a user returned to the client."""

    id: int
    username: str
    # The client's code can derive role‑specific behaviour from this field.
    role: str

    model_config = ConfigDict(from_attributes=True)


class Token(BaseModel):
    """JWT access token returned on successful login."""

    access_token: str
    token_type: str = "bearer"


# ---------------------------------------------------------------------------
# Verb schemas
# ---------------------------------------------------------------------------

class VerbOut(BaseModel):
    """Serialised representation of an irregular verb."""

    id: int
    infinitive: str
    past: str
    participle: str
    translation: str
    example_b2: str

    model_config = ConfigDict(from_attributes=True)


class VerbCreate(BaseModel):
    """Payload for creating a new verb (admin only)."""

    infinitive: str = Field(..., description="Infinitive form of the verb")
    past: str = Field(..., description="Past simple form of the verb")
    participle: str = Field(..., description="Past participle form of the verb")
    translation: str = Field(..., description="Translation of the verb")
    example_b2: str = Field(..., description="Example sentence at B2 level")


class VerbUpdate(BaseModel):
    """Partial update for an existing verb."""

    infinitive: Optional[str] = None
    past: Optional[str] = None
    participle: Optional[str] = None
    translation: Optional[str] = None
    example_b2: Optional[str] = None


# ---------------------------------------------------------------------------
# Practice and XP schemas
# ---------------------------------------------------------------------------

class PracticeAnswerRequest(BaseModel):
    """Payload sent by the client when answering a verb during practice."""

    verb_id: int = Field(..., description="ID of the verb being practised")
    correct: bool = Field(..., description="Whether the answer provided was correct")


class PracticeAnswerResponse(BaseModel):
    """Response returned after a user submits an answer."""

    xp_gain: int = Field(..., description="XP earned for this answer")
    total_xp: int = Field(..., description="Total XP accumulated by the user")
    level: int = Field(..., description="Current level of the user based on XP")
    xp_to_next: int = Field(..., description="XP needed to reach the next level")


class StatsResponse(BaseModel):
    """Aggregated statistics for a user."""

    total_xp: int
    level: int
    xp_to_next: int
    verbs_total: int
    verbs_learned: int
    verbs_due: int
    average_streak: float
    total_mistakes: int
    mastery_percentage: float


class AchievementOut(BaseModel):
    """Representation of an achievement definition."""

    id: int
    slug: str
    name: str
    description: str
    model_config = ConfigDict(from_attributes=True)


class UserAchievementOut(BaseModel):
    """Representation of an achievement unlocked by a user."""

    id: int
    achievement_id: int
    unlocked_at: datetime
    slug: str
    name: str
    description: str

    model_config = ConfigDict(from_attributes=True)
