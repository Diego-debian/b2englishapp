"""
Data models for the English learning platform.

This module defines a relational schema that supports multi‑user operation,
gamification and extensibility.  The models are defined using SQLAlchemy's
declarative system and are intended to be migrated using Alembic.  No
``Base.metadata.create_all()`` should be executed from within application
code; instead, migrations define the schema evolution.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional

from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime,
    ForeignKey,
    Enum as SAEnum,
    Text,
    Boolean,
)
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()


class UserRole(str, Enum):
    """Enumeration of user roles."""

    student = "student"
    admin = "admin"


class User(Base):
    """Represents a learner or administrator of the system."""

    __tablename__ = "users"
    id: int = Column(Integer, primary_key=True, index=True)
    username: str = Column(String(50), unique=True, nullable=False, index=True)
    hashed_password: str = Column(String(256), nullable=False)
    role: UserRole = Column(SAEnum(UserRole), default=UserRole.student, nullable=False)

    # Relationships
    verb_progress = relationship(
        "UserVerbProgress",
        back_populates="user",
        cascade="all, delete-orphan",
    )
    activities = relationship("Activity", back_populates="user", cascade="all, delete-orphan")
    xp_ledger = relationship("XPLedger", back_populates="user", cascade="all, delete-orphan")
    achievements = relationship("UserAchievement", back_populates="user", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<User {self.id} {self.username}>"


class Module(Base):
    """Catalog of learning modules (verbs, vocabulary, tenses, games, etc.)."""

    __tablename__ = "modules"
    id: int = Column(Integer, primary_key=True, index=True)
    slug: str = Column(String(50), unique=True, nullable=False)
    name: str = Column(String(100), nullable=False)
    description: Optional[str] = Column(Text)

    activities = relationship("Activity", back_populates="module", cascade="all, delete-orphan")


class ActivityType(Base):
    """Types of activities supported by the system (e.g. quiz, drag & drop)."""

    __tablename__ = "activity_types"
    id: int = Column(Integer, primary_key=True, index=True)
    code: str = Column(String(50), unique=True, nullable=False)
    name: str = Column(String(100), nullable=False)
    description: Optional[str] = Column(Text)

    activities = relationship("Activity", back_populates="activity_type", cascade="all, delete-orphan")


class Activity(Base):
    """Records a learning or game session started by a user."""

    __tablename__ = "activities"
    id: int = Column(Integer, primary_key=True, index=True)
    user_id: int = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    module_id: int = Column(Integer, ForeignKey("modules.id", ondelete="SET NULL"), nullable=True)
    activity_type_id: int = Column(Integer, ForeignKey("activity_types.id", ondelete="SET NULL"), nullable=True)
    started_at: datetime = Column(DateTime, default=datetime.utcnow, nullable=False)
    completed_at: Optional[datetime] = Column(DateTime)
    xp_earned: int = Column(Integer, default=0, nullable=False)

    # Relationships
    user = relationship("User", back_populates="activities")
    module = relationship("Module", back_populates="activities")
    activity_type = relationship("ActivityType", back_populates="activities")
    answers = relationship(
        "ActivityAnswer",
        back_populates="activity",
        cascade="all, delete-orphan",
    )
    xp_entries = relationship("XPLedger", back_populates="activity", cascade="all, delete-orphan")


class ActivityAnswer(Base):
    """Stores each answer given by a user during an activity."""

    __tablename__ = "activity_answers"
    id: int = Column(Integer, primary_key=True, index=True)
    activity_id: int = Column(Integer, ForeignKey("activities.id", ondelete="CASCADE"), nullable=False)
    question_id: int = Column(Integer, nullable=False)  # references a verb_id or other question bank id
    user_answer: str = Column(String(255), nullable=False)
    correct: bool = Column(Boolean, nullable=False)
    timestamp: datetime = Column(DateTime, default=datetime.utcnow, nullable=False)
    xp_delta: int = Column(Integer, default=0, nullable=False)

    # Relationships
    activity = relationship("Activity", back_populates="answers")


class Verb(Base):
    """Table of irregular verbs."""

    __tablename__ = "verbs"
    id: int = Column(Integer, primary_key=True, index=True)
    infinitive: str = Column(String(50), unique=True, nullable=False)
    past: str = Column(String(50), nullable=False)
    participle: str = Column(String(50), nullable=False)
    translation: str = Column(String(100), nullable=False)
    example_b2: str = Column(Text, nullable=False)

    progress_records = relationship(
        "UserVerbProgress",
        back_populates="verb",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        return f"<Verb {self.infinitive}>"


class UserVerbProgress(Base):
    """Progress of a user for a specific verb."""

    __tablename__ = "user_verb_progress"
    id: int = Column(Integer, primary_key=True, index=True)
    user_id: int = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    verb_id: int = Column(Integer, ForeignKey("verbs.id", ondelete="CASCADE"), nullable=False)
    srs_date: datetime = Column(DateTime, default=datetime.utcnow, nullable=False)
    mistakes: int = Column(Integer, default=0, nullable=False)
    streak: int = Column(Integer, default=0, nullable=False)
    # optional mastery level (0-100)
    mastery_level: int = Column(Integer, default=0, nullable=False)

    user = relationship("User", back_populates="verb_progress")
    verb = relationship("Verb", back_populates="progress_records")

    __table_args__ = (
        # unique constraint prevents duplicate progress for same user and verb
        {'sqlite_autoincrement': True},
    )

    def __repr__(self) -> str:
        return f"<UserVerbProgress user={self.user_id} verb={self.verb_id} streak={self.streak}>"


class XPLedger(Base):
    """Ledger of XP transactions.  Each time a user earns or loses XP, a record is created."""

    __tablename__ = "xp_ledger"
    id: int = Column(Integer, primary_key=True, index=True)
    user_id: int = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    activity_id: Optional[int] = Column(Integer, ForeignKey("activities.id", ondelete="SET NULL"))
    xp_delta: int = Column(Integer, nullable=False)
    reason: str = Column(String(255), nullable=False)
    created_at: datetime = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship("User", back_populates="xp_ledger")
    activity = relationship("Activity", back_populates="xp_entries")

    def __repr__(self) -> str:
        sign = "+" if self.xp_delta >= 0 else ""
        return f"<XP {sign}{self.xp_delta} for user {self.user_id} ({self.reason})>"


class Achievement(Base):
    """Static definitions of achievements."""

    __tablename__ = "achievements"
    id: int = Column(Integer, primary_key=True, index=True)
    slug: str = Column(String(100), unique=True, nullable=False)
    name: str = Column(String(100), nullable=False)
    description: str = Column(Text, nullable=False)
    # criteria can be encoded as JSON or hard‑coded rules in services

    users = relationship("UserAchievement", back_populates="achievement", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Achievement {self.slug}>"


class UserAchievement(Base):
    """Association table between users and achievements."""

    __tablename__ = "user_achievements"
    id: int = Column(Integer, primary_key=True, index=True)
    user_id: int = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    achievement_id: int = Column(Integer, ForeignKey("achievements.id", ondelete="CASCADE"), nullable=False)
    unlocked_at: datetime = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship("User", back_populates="achievements")
    achievement = relationship("Achievement", back_populates="users")

    __table_args__ = (
        # a user cannot unlock the same achievement twice
        {'sqlite_autoincrement': True},
    )

    def __repr__(self) -> str:
        return f"<UserAchievement user={self.user_id} achievement={self.achievement_id}>"