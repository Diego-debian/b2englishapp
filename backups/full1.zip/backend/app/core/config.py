"""
Application configuration.

This module defines a simple ``Settings`` class that loads
configuration values from environment variables.  Using a plain Python
class avoids a dependency on ``pydantic_settings``, which may not be
available in all environments.  Values are lazily loaded via the
``get_settings`` function and cached using ``functools.lru_cache``.
"""

from __future__ import annotations

import os
from functools import lru_cache


class Settings:
    """Simple container for configuration values with sensible defaults."""

    def __init__(self) -> None:
        # Secret key used for JWT signing.  Override in production via env var.
        self.SECRET_KEY: str = os.getenv("SECRET_KEY", "change-me")
        # Algorithm used for JWT signing
        self.ALGORITHM: str = os.getenv("ALGORITHM", "HS256")
        # Token expiry (minutes)
        try:
            self.ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30"))
        except ValueError:
            self.ACCESS_TOKEN_EXPIRE_MINUTES = 30
        # Allowed CORS origins (comma-separated list)
        self.ALLOWED_ORIGINS: str = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return a cached instance of :class:`Settings`."""
    return Settings()
