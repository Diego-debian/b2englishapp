"""
Statistics routes.

This module provides a summary of a user's learning statistics,
including XP, level, progress with verbs and basic mastery metrics.
The statistics are computed on demand and do not include any
personally identifying information beyond the authenticated user.
"""

from datetime import datetime
from typing import Dict

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..services import auth as auth_service
from ..services import xp as xp_service


router = APIRouter(prefix="/stats", tags=["stats"])


@router.get("/overview", response_model=schemas.StatsResponse)
def get_user_stats(
    current_user: models.User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db),
) -> schemas.StatsResponse:
    """Return a summary of the authenticated user's learning statistics."""
    # XP and level
    total_xp, level, xp_to_next = xp_service.compute_user_xp_and_level(db, current_user)
    # Verb counts
    total_verbs = db.query(models.Verb).count()
    # All progress records for this user
    progress_records = (
        db.query(models.UserVerbProgress)
        .filter(models.UserVerbProgress.user_id == current_user.id)
        .all()
    )
    verbs_learned = len(progress_records)
    now = datetime.utcnow()
    verbs_due = sum(1 for p in progress_records if p.srs_date <= now)
    total_streak = sum(p.streak for p in progress_records)
    total_mistakes = sum(p.mistakes for p in progress_records)
    average_streak = (total_streak / verbs_learned) if verbs_learned > 0 else 0.0
    mastered = sum(1 for p in progress_records if p.streak >= 5)
    mastery_percentage = (mastered / verbs_learned * 100) if verbs_learned > 0 else 0.0
    return schemas.StatsResponse(
        total_xp=total_xp,
        level=level,
        xp_to_next=xp_to_next,
        verbs_total=total_verbs,
        verbs_learned=verbs_learned,
        verbs_due=verbs_due,
        average_streak=round(average_streak, 2),
        total_mistakes=total_mistakes,
        mastery_percentage=round(mastery_percentage, 2),
    )
