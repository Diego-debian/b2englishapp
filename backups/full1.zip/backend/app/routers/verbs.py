"""
Verb management routes.

This module exposes CRUD endpoints for the ``Verb`` model.  Listing and
retrieving verbs is open to authenticated users, while creation,
modification and deletion are restricted to administrators.  The role
check is performed at runtime based on the ``role`` field on the
``User`` model.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..services import auth as auth_service


router = APIRouter(prefix="/verbs", tags=["verbs"])


@router.get("", response_model=list[schemas.VerbOut])
def list_verbs(db: Session = Depends(get_db)) -> list[models.Verb]:
    """Return all verbs sorted alphabetically by infinitive."""
    return db.query(models.Verb).order_by(models.Verb.infinitive.asc()).all()


@router.get("/{verb_id}", response_model=schemas.VerbOut)
def get_verb(verb_id: int, db: Session = Depends(get_db)) -> models.Verb:
    """Retrieve a verb by its ID."""
    verb = db.get(models.Verb, verb_id)
    if not verb:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Verb not found")
    return verb


@router.post("", response_model=schemas.VerbOut, status_code=status.HTTP_201_CREATED)
def create_verb(
    payload: schemas.VerbCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth_service.get_current_user),
) -> models.Verb:
    """Create a new verb.  Only administrators may perform this action."""
    if current_user.role != models.UserRole.admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorised to create verbs")
    verb = models.Verb(
        infinitive=payload.infinitive,
        past=payload.past,
        participle=payload.participle,
        translation=payload.translation,
        example_b2=payload.example_b2,
    )
    db.add(verb)
    db.commit()
    db.refresh(verb)
    return verb


@router.put("/{verb_id}", response_model=schemas.VerbOut)
def update_verb(
    verb_id: int,
    payload: schemas.VerbUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth_service.get_current_user),
) -> models.Verb:
    """Update an existing verb.  Only administrators may modify verbs."""
    if current_user.role != models.UserRole.admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorised to update verbs")
    verb = db.get(models.Verb, verb_id)
    if not verb:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Verb not found")
    update_data = payload.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(verb, field, value)
    db.add(verb)
    db.commit()
    db.refresh(verb)
    return verb


@router.delete("/{verb_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_verb(
    verb_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth_service.get_current_user),
) -> None:
    """Delete a verb.  Only administrators may delete verbs."""
    if current_user.role != models.UserRole.admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorised to delete verbs")
    verb = db.get(models.Verb, verb_id)
    if not verb:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Verb not found")
    db.delete(verb)
    db.commit()
    return None
