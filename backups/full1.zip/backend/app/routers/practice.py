"""
Practice session routes.

This module defines endpoints for starting a practice session and
submitting answers.  It leverages the spaced repetition service to
select which verbs should be practised and the XP service to record
earned points in a ledger.  All practice actions are scoped to the
authenticated user; the client should **not** supply any user IDs.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..database import get_db
from ..services import auth as auth_service
from ..services import srs as srs_service
from ..services import xp as xp_service
from .. import models, schemas


router = APIRouter(prefix="/practice", tags=["practice"])


@router.get("/start", response_model=list[schemas.VerbOut])
def start_practice(
    limit: int = 10,
    current_user: models.User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db),
) -> list[models.Verb]:
    """Return a list of verbs for the user to practise next.

    The list is selected by the spaced repetition algorithm and will
    create progress records for new verbs as needed.  The default limit
    of 10 can be overridden by providing the ``limit`` query parameter.
    """
    return srs_service.select_verbs_for_practice(db, user=current_user, limit=limit)


@router.post("/answer", response_model=schemas.PracticeAnswerResponse)
def submit_answer(
    payload: schemas.PracticeAnswerRequest,
    current_user: models.User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db),
) -> schemas.PracticeAnswerResponse:
    """Process an answer to a verb and return XP and level information.

    The request body must specify the ``verb_id`` being answered and
    whether the answer was correct.  XP is awarded (or a small amount
    granted for incorrect answers) and the user's progress record and
    XP ledger are updated atomically.  The response includes the XP
    gained for this answer, the user's total XP, current level and the
    XP required to reach the next level.
    """
    # Validate that the verb exists
    verb = db.get(models.Verb, payload.verb_id)
    if not verb:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Verb not found")
    # Update progress and get XP gain
    _, xp_gain = srs_service.update_verb_progress(db, user=current_user, verb=verb, correct=payload.correct)
    # Record XP in ledger with a descriptive reason
    reason = "correct answer" if payload.correct else "incorrect answer"
    xp_service.record_xp(db, user=current_user, xp_delta=xp_gain, reason=reason)
    # Recompute total XP and level
    total_xp, level, xp_to_next = xp_service.compute_user_xp_and_level(db, current_user)
    return schemas.PracticeAnswerResponse(
        xp_gain=xp_gain,
        total_xp=total_xp,
        level=level,
        xp_to_next=xp_to_next,
    )
