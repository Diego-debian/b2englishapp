"""
Achievements routes.

Expose endpoints to view available achievements and those unlocked by the
authenticated user.  Unlocking achievements is handled elsewhere (for
example, in services that monitor XP or streak events) and is not part
of these routes.
"""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..services import auth as auth_service
from .. import models, schemas


router = APIRouter(prefix="/achievements", tags=["achievements"])


@router.get("", response_model=list[schemas.AchievementOut])
def list_achievements(db: Session = Depends(get_db)) -> list[models.Achievement]:
    """Return all defined achievements."""
    return db.query(models.Achievement).order_by(models.Achievement.id.asc()).all()


@router.get("/my", response_model=list[schemas.UserAchievementOut])
def get_my_achievements(
    current_user: models.User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db),
) -> list[schemas.UserAchievementOut]:
    """Return achievements unlocked by the current user."""
    # Join user achievements with achievement definitions for easier output
    records = (
        db.query(models.UserAchievement, models.Achievement)
        .join(models.Achievement, models.UserAchievement.achievement_id == models.Achievement.id)
        .filter(models.UserAchievement.user_id == current_user.id)
        .all()
    )
    result: list[schemas.UserAchievementOut] = []
    for ua, ach in records:
        result.append(
            schemas.UserAchievementOut(
                id=ua.id,
                achievement_id=ach.id,
                unlocked_at=ua.unlocked_at,
                slug=ach.slug,
                name=ach.name,
                description=ach.description,
            )
        )
    return result
