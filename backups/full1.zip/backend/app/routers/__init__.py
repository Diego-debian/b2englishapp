"""API route modules for the FastAPI application.

Each router defines a set of endpoints grouped by logical concern
(authentication, verbs, practice sessions, statistics, achievements, etc.)
and is registered in ``main.py``.  Splitting the API into multiple
routers improves maintainability and testability.
"""
