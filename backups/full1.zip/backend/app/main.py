"""
main.py
--------

Entry point for the FastAPI application.

This module constructs the application instance, configures CORS and
registers the various API routers defined under ``routers/``.  No
database tables are created here; instead, use Alembic to manage the
schema.  To start the server locally, run ``uvicorn app.main:app``.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .core.config import get_settings
from .routers import auth, verbs, practice, stats, achievements


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title="English Learning Platform", version="0.2.0")
    # Configure CORS based on settings.  Multiple origins can be provided
    # as a comma‑separated list in the ALLOWED_ORIGINS environment var.
    origins = [o.strip() for o in settings.ALLOWED_ORIGINS.split(",") if o.strip()]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    # Register routers
    app.include_router(auth.router)
    app.include_router(verbs.router)
    app.include_router(practice.router)
    app.include_router(stats.router)
    app.include_router(achievements.router)
    return app


app = create_app()
