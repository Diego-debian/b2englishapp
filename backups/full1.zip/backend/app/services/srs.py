"""
Spaced repetition and practice logic for verbs.

This service encapsulates the algorithm used to select which verbs a user
should practise next and how to update progress based on correct or
incorrect answers.  It operates on SQLAlchemy sessions and the data
models defined in ``models``.
"""

from datetime import datetime, timedelta
from typing import List, Tuple

from sqlalchemy import select, func
from sqlalchemy.orm import Session

from .. import models


def select_verbs_for_practice(db: Session, user: models.User, limit: int = 10) -> List[models.Verb]:
    """Return up to ``limit`` verbs that the user should practise next.

    The selection follows a simple spaced repetition algorithm:

    1. Verbs with ``srs_date`` <= now are due and selected first.
    2. New verbs (without any progress record) fill remaining slots.
    3. If still not enough, verbs with the lowest streaks are selected.

    New progress records are created as needed.
    """
    now = datetime.utcnow()
    verbs_to_practice: List[models.Verb] = []

    # 1) Due verbs
    due_stmt = (
        select(models.Verb)
        .join(models.UserVerbProgress, models.UserVerbProgress.verb_id == models.Verb.id)
        .where(models.UserVerbProgress.user_id == user.id)
        .where(models.UserVerbProgress.srs_date <= now)
        .order_by(models.UserVerbProgress.srs_date.asc())
        .limit(limit)
    )
    due_verbs = db.scalars(due_stmt).all()
    if len(due_verbs) >= limit:
        return due_verbs
    verbs_to_practice.extend(due_verbs)
    remaining = limit - len(due_verbs)

    # 2) New verbs not yet practised by the user
    if remaining > 0:
        # find verbs ids the user already has progress for
        subquery = select(models.UserVerbProgress.verb_id).where(models.UserVerbProgress.user_id == user.id)
        new_stmt = (
            select(models.Verb)
            .where(models.Verb.id.not_in(subquery))
            .order_by(func.random())
            .limit(remaining)
        )
        new_verbs = db.scalars(new_stmt).all()
        # create initial progress for these verbs
        for verb in new_verbs:
            prog = models.UserVerbProgress(
                user_id=user.id,
                verb_id=verb.id,
                srs_date=now,
                mistakes=0,
                streak=0,
                mastery_level=0,
            )
            db.add(prog)
        if new_verbs:
            db.commit()
        verbs_to_practice.extend(new_verbs)
        remaining = limit - len(verbs_to_practice)

    # 3) Fallback: low streak / random verbs
    if remaining > 0:
        fallback_limit = remaining
        fallback_stmt = (
            select(models.Verb)
            .join(models.UserVerbProgress, models.UserVerbProgress.verb_id == models.Verb.id)
            .where(models.UserVerbProgress.user_id == user.id)
            .order_by(models.UserVerbProgress.streak.asc(), models.UserVerbProgress.srs_date.asc())
            .limit(fallback_limit)
        )
        fallback_verbs = db.scalars(fallback_stmt).all()
        verbs_to_practice.extend(fallback_verbs)
    return verbs_to_practice[:limit]


def update_verb_progress(
    db: Session, user: models.User, verb: models.Verb, correct: bool
) -> Tuple[models.UserVerbProgress, int]:
    """Update the user's progress for a given verb based on correctness.

    Returns a tuple of the updated progress record and the amount of XP to
    award.  The XP calculation mirrors the current MVP: correct answers
    earn increasing XP based on streak, while incorrect answers earn
    minimal XP to encourage continued practice.
    """
    now = datetime.utcnow()
    # Get or create progress record
    prog = (
        db.query(models.UserVerbProgress)
        .filter(models.UserVerbProgress.user_id == user.id, models.UserVerbProgress.verb_id == verb.id)
        .first()
    )
    if not prog:
        prog = models.UserVerbProgress(
            user_id=user.id,
            verb_id=verb.id,
            srs_date=now,
            mistakes=0,
            streak=0,
            mastery_level=0,
        )
        db.add(prog)
        db.commit()
        db.refresh(prog)

    xp_gain = 0
    if correct:
        prog.streak += 1
        # interval doubling up to 32 days
        interval_days = min(2 ** prog.streak, 32)
        prog.srs_date = now + timedelta(days=interval_days)
        # XP calculation: base 10 + 10 per streak up to 5 (so 10..60)
        xp_gain = 10 * (1 + min(prog.streak, 5))
    else:
        prog.mistakes += 1
        prog.streak = 0
        prog.srs_date = now + timedelta(days=1)
        xp_gain = 2  # minimal XP
    db.add(prog)
    db.commit()
    db.refresh(prog)
    return prog, xp_gain