"""
Experience (XP) management utilities.

This service encapsulates functions for recording XP transactions in the
``xp_ledger`` table and computing aggregate statistics such as total
XP and level.  Storing XP in a ledger instead of a single counter
improves auditability and makes it easy to reverse or recompute totals.
"""

from datetime import datetime
from typing import Optional, Tuple

from sqlalchemy.orm import Session

from .. import models


def record_xp(
    db: Session,
    user: models.User,
    xp_delta: int,
    reason: str,
    activity: Optional[models.Activity] = None,
) -> models.XPLedger:
    """Insert a new XP transaction into the ledger and return it."""
    entry = models.XPLedger(
        user_id=user.id,
        activity_id=activity.id if activity else None,
        xp_delta=xp_delta,
        reason=reason,
        created_at=datetime.utcnow(),
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


def compute_user_xp_and_level(db: Session, user: models.User) -> Tuple[int, int, int]:
    """Compute the total XP, current level and XP needed to reach the next level.

    Uses a simple formula: level 1 at 0 XP, then 100 XP per level.  The XP
    required for the next level increases by 20 for each subsequent level.

    Returns a tuple (total_xp, level, xp_to_next).
    """
    # Sum all xp transactions
    total_xp = db.query(models.XPLedger).with_entities(func.coalesce(func.sum(models.XPLedger.xp_delta), 0)).filter(
        models.XPLedger.user_id == user.id
    ).scalar() or 0
    # Level calculation
    level = 1
    xp_threshold = 100
    remaining_xp = total_xp
    while remaining_xp >= xp_threshold:
        remaining_xp -= xp_threshold
        level += 1
        xp_threshold += 20  # each level requires 20 more XP than the previous
    xp_to_next = xp_threshold - remaining_xp
    return total_xp, level, xp_to_next


# SQLAlchemy func import required for compute_user_xp_and_level
from sqlalchemy import func