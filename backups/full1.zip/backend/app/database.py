"""
database.py
---------------

Database configuration and session management for the FastAPI backend.  The
PostgreSQL connection URL is read from the ``DATABASE_URL`` environment
variable.  A SQLAlchemy ``Engine`` and scoped ``SessionLocal`` are provided,
along with a convenience dependency ``get_db`` that yields a session for use
in API endpoints.
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# We import Base from our models module.  Alembic uses this to generate
# migrations.  Do not call ``Base.metadata.create_all()`` in application code.
from .models import Base

# Read the database URL from the environment.  Falling back to an in‑memory
# SQLite database in development makes it easy to run the API without a
# PostgreSQL instance.  In production you **must** set DATABASE_URL.
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./db.sqlite3")

# Create a SQLAlchemy engine.  ``pool_pre_ping`` ensures that broken
# connections are recycled.
engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
)

# Create a configured "Session" class and a session instance for each request.
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# The declarative base is defined in ``app.models``.  Importing it here
# simply re‑exports it for Alembic's autogeneration.


def get_db():
    """Provide a transactional scope around a series of operations.

    This function is designed to be used as a FastAPI dependency. It
    yields a SQLAlchemy session and ensures that the session is closed
    after the request is processed.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()