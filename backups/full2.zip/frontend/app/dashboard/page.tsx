"use client";

import Link from 'next/link';
import { BarChart2, Trophy, LogOut } from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '../../hooks/useAuth';

interface Stats {
  streak: number;
  totalMistakes: number;
}

export default function Dashboard() {
  const { user, token, logout, isLoading } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState<Stats>({ streak: 0, totalMistakes: 0 });
  const apiBase = (process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8001").trim();
  const [practiceVerbs, setPracticeVerbs] = useState<
    { id: number; infinitive: string; past: string; participle: string; translation: string; example_b2: string }[]
  >([]);

  // Declaración de fetchPractice fuera del useEffect
  async function fetchPractice() {
    try {
      const res = await fetch(`${apiBase}/verbs/${user?.id}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!res.ok) return;
      const data = await res.json();
      setPracticeVerbs(data);
    } catch (err) {
      console.warn("Error fetching practise verbs", err);
    }
  }

  useEffect(() => {
    if (!isLoading && !user) {
      router.push('/login');
    }
  }, [user, isLoading, router]);

  useEffect(() => {
    if (user && token) {
      // Fetch real stats from backend if available, for now use dummy
      setStats({ streak: 3, totalMistakes: 1 });

      // Fetch practice verbs
      fetchPractice();
    }
  }, [user, token, apiBase]);

  if (isLoading) {
    return <div className="flex justify-center items-center min-h-screen">Cargando...</div>;
  }

  if (!user) {
    return null; // Will redirect
  }

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  return (
    <main className="max-w-4xl mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-semibold">Panel de Control</h2>
        <div className="flex items-center gap-4">
          <span className="text-lg">Hola, {user.username}!</span>
          <span className="text-sm text-gray-600">XP: {user.total_xp}</span>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700"
          >
            <LogOut className="w-4 h-4" />
            Cerrar sesión
          </button>
        </div>
      </div>
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="p-4 bg-white rounded-lg shadow flex items-center">
          <Trophy className="w-8 h-8 text-yellow-500 mr-4" />
          <div>
            <p className="text-sm text-gray-500">Racha Actual</p>
            <p className="text-xl font-bold">{stats.streak} días</p>
          </div>
        </div>
        <div className="p-4 bg-white rounded-lg shadow flex items-center">
          <BarChart2 className="w-8 h-8 text-green-500 mr-4" />
          <div>
            <p className="text-sm text-gray-500">Errores Totales</p>
            <p className="text-xl font-bold">{stats.totalMistakes}</p>
          </div>
        </div>
      </div>
      {/* Upcoming verbs section */}
      <section className="mb-8">
        <h3 className="text-2xl font-semibold mb-4">Próximos verbos a practicar</h3>
        {practiceVerbs.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {practiceVerbs.map((verb) => (
              <div key={verb.id} className="p-4 bg-white rounded-lg shadow">
                <h4 className="text-lg font-bold mb-1 text-gray-800">{verb.infinitive}</h4>
                <p className="text-sm text-gray-600 mb-1">
                  Pasado: <span className="font-medium text-gray-800">{verb.past}</span>
                </p>
                <p className="text-sm text-gray-600 mb-1">
                  Participio: <span className="font-medium text-gray-800">{verb.participle}</span>
                </p>
                <p className="text-sm text-gray-600">
                  Traducción: <span className="font-medium text-gray-800">{verb.translation}</span>
                </p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500">No hay verbos pendientes en este momento.</p>
        )}
      </section>
      {/* Action buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Link
          href="/dashboard/practice"
          className="flex-1 inline-flex justify-center items-center px-6 py-3 bg-blue-600 text-white rounded-md shadow hover:bg-blue-700 transition"
        >
          Iniciar Sesión de Práctica
        </Link>
        <Link
          href="/dashboard/verbs"
          className="flex-1 inline-flex justify-center items-center px-6 py-3 bg-green-600 text-white rounded-md shadow hover:bg-green-700 transition"
        >
          Gestionar Verbos
        </Link>
      </div>
    </main>
  );
}